#!/bin/bash
# final20 (2026-10-25): CUDA builds of dev 561966ec, PR #2 3ce988da, fix A f30c7b23 (final6 make line)
W=~/colibri-bench/cw22
B=~/colibri-bench/final20/builds; mkdir -p $B
MAKE_LINE="make -f Makefile.deepseek-v4 deepseek-v4 CUDA=1 CUDA_HOME=/usr NVCC=/usr/bin/nvcc CUDA_ARCH=sm_86 NO_TC=1 -j14"
for n in dev pr2 fixa; do t=$W/f20-$n
  ( cd $t/c && echo "tree=$t sha=$(git rev-parse HEAD) tree_sha=$(git rev-parse "HEAD^{tree}") start=$(date -Is)" &&
    env -i PATH=/usr/local/bin:/usr/bin:/bin HOME=$HOME nice -n 15 $MAKE_LINE; echo "EXIT=$? end=$(date -Is)" ) > $B/f20-$n.build.log 2>&1
  echo "f20-$n $(tail -1 $B/f20-$n.build.log) warnings=$(grep -iE "warning|error" $B/f20-$n.build.log | grep -vc lto-wrapper) bin=$(sha256sum $t/c/deepseek_v4 | cut -c1-16)" >> $B/status
done
echo done >> $B/status
