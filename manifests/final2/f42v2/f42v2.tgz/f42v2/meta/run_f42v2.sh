#!/bin/bash
# F42 v2: is the slower decode right after a long GPU-bank prefill (final PR #1 benchmark: the
# 24-token answer to bench_pr1.py's 1,992-token request, -8.6 % vs dev's CPU-union prefill, texts
# identical) caused by the RAM tier the bank refill leaves behind (H1)? The first diagnosis
# (final2/f42) measured the 3100 MiB mirror-reserve cost (~2.2-2.5 %) but its prompt gave different
# text on the two prefill paths. Here: bench_pr1.py's first request exactly (identical text on both
# paths), the CPU union forced with COLI_CUDA_MOE_BATCH_MIN so the reserve stays 3100 MiB, and a
# logging-only probe build that prints the decode MoE / expert-store counters per token.
# H1 predicts: GB - U = extra fetch_wait (RAM misses = O_DIRECT SSD reads) concentrated in the first
# decode tokens, uploads ~equal, attach ~equal.
#
# shadowfax only. Stops llama.cpp ONCE; the EXIT trap ALWAYS restarts it and waits for /health ok.
# Launch (own transient unit, survives an ssh drop):
#   systemd-run --user --unit=colibri-final2-f42v2 --collect -p TimeoutStopSec=900 \
#     -p WorkingDirectory=/home/maplemercury/colibri-bench/final2 /bin/bash /home/maplemercury/colibri-bench/final2/run_f42v2.sh
#   progress: tail /home/maplemercury/colibri-bench/final2/f42v2/run.log
# CPU-only check first (nothing stopped or started, exits before the trap exists):
#   PREFLIGHT_ONLY=1 /bin/bash /home/maplemercury/colibri-bench/final2/run_f42v2.sh   (log: final2/f42v2-preflight/run.log)
#
# Builds (pr2 tip d0e19de2; with no PR #2 switch it runs the PR #1 code paths):
#   /tmp/cw/r8-pr2-f42probe  d0e19de2 + final2/probe/f42v2_probe_patch.py (diff: probe/r8-pr2-f42probe.diff,
#                            build_r8.sh). V4_DEC_TRACE=2 prints, on stderr only, reading counters the
#                            engine already keeps: v4_dec_trace_start (prefill MoE path counts: GPU bank /
#                            CPU union / rows, store totals), v4_dec_res (RAM tier per layer at decode
#                            start: residents with usage and age, pins), v4_dec_trace (one line per
#                            emitted token: cumulative decode MoE counters of v4_dec_moe -- fetch_wait_s,
#                            attach_s, uploads, gpu_s -- and the store's requests/hits/misses/bytes,
#                            disk_s, wait_s) and v4_dec_layer (per decode token-layer: routed ids,
#                            hits, misses, uploads, fetch/attach ms).
#   /tmp/cw/r6-pr2           d0e19de2 unmodified (the binary of the final PR #2 and F42 runs)
# Every sample: --ram 40 --ctx 8192, COMMON_ENV of final_common.sh (COLI_CUDA_MOE_BATCH=1), a cold
# server per sample (env -i), V4_SERVE_STATS_LOG=1 (v4_serve_turn / v4_dec_moe), DSV4_DECODE_PROF=1
# (decprof per token), V4_DEC_TRACE=2 (read by the probe build only).
# Client bench_f42v2.py: bench_pr1.py REQUESTS[0] byte for byte (prompt sha256 e13a02a3..., max_tokens
# 100, same request body), per-chunk arrival times; reference answer 32534c06... (24 chunks + EOS).
# Arms (switches checked against the tree's getenv calls and docs/deepseek-v4.md at d0e19de2):
#   W    warm-up: GB's config on the probe build, ONE sample first, discarded (warms the OS page cache
#        after the llama stop; the first sample of the final PR #1 run was partly cold)
#   GB   probe build: GPU-bank prefill (132-slot bank), decode-mirror reserve 3100 MiB (logged)
#   U    probe build: GB + COLI_CUDA_MOE_BATCH_MIN=100000. The one getenv of that switch is the per-call
#        gate in coli_v4_gpu_moe_batch_union (hint 1,992+ fresh tokens < 100000 -> return -1 before the
#        bank exists -> CPU union, v4_moe_batch_union). The reserve (v4_gpu_mirror_reserve_size /
#        v4_gpu_mirror_reserve_mb) reads COLI_CUDA_MOE_BATCH (via coli_v4_gpu_moe_batch_wanted),
#        COLI_CUDA_MOE_DOUBLE and DSV4_CUDA_VRAM_RESERVE_MB only, so U keeps 3100 MiB (logged per sample).
#        Proof per sample: no "moe-batch=on bank=" / "moe-batch refill" line, v4_dec_trace_start bank=0
#        union>0 (GB: bank>0, union=0 expected, union>0 only logged as a NOTE), and the same
#        "mirror-reserve=3100MiB" line as GB (plus, in the summary, U's decode VRAM plateau ~= GB's).
#   GBn  GB's env on the non-probe r6-pr2 binary, 3 samples: the probe changes neither speed nor text.
# Order: W, then 5 rounds of GB/U alternating which goes first, GBn after rounds 2, 4 and 5.
# Expected window ~37 min (GB/GBn/W ~105 s, U ~245 s per sample, + llama stop/restore); hard cap
# MAX_GPU_S = 50 min (a sample that would overrun it, with 240 s kept for the restore, is skipped).
# Abort (EXIT trap restores llama) when a premise breaks: a failed client, no probe lines in a probe
# arm, a reserve other than 3100 MiB, the bank used in U or not used in GB/GBn/W.
# Captured per sample (final2/f42v2/<arm>/s<k>/): serve.log, bench.jsonl (per-chunk times, text),
# nvsmi.csv every 1 s, sample.txt, engine_environ.txt, procs.txt, gpu_*.csv, mode.txt.
# Summary: analyze_f42v2.py summarize f42v2 (summary.txt / summary.json), then f42v2.tgz.
# Uses final_common.sh's client case "f42v2" (added 2026-10-16; previous version kept as
# final_common.sh.pre-f42v2; the other cases are unchanged).

EXP=f42v2
[ "${PREFLIGHT_ONLY:-0}" = 1 ] && EXP=f42v2-preflight
MAX_GPU_S=$((50 * 60))      # hard cap on the llama-down window
NVSMI_MS=1000
source /home/maplemercury/colibri-bench/final2/final_common.sh

PR2_SHA=d0e19de23c3baf314ee932347c42d5f6d49ef4fb
PR2=/tmp/cw/r6-pr2
PR2_BIN_SHA=63a667bac98a95daffc42428f0a82a1fd5051588047b524d8f8b1c564a20b926
PROBE=/tmp/cw/r8-pr2-f42probe
PROBE_DIFF=$FINAL/probe/r8-pr2-f42probe.diff
PROBE_DIFF_SHA=a003effa519301065e77ae3aeb9e67d2ad42ea27b3bf66ad5da536e5cd3690c4
PROBE_BIN_SHA=3de5acf4d30720735081153a9d8a9c3ad1a9ec2e7b8cbe81e2aace3f80508b93
REF_TEXT_SHA=32534c06abd640d59d2eb39ab6609051f63e9876f533aad1d75dd5cd775835ba
MODE_RE='moe-batch=on|moe-batch=off|moe-double|mirror-reserve|mirror-cache:|DSV4 CUDA\] device|v4_hot_policy|ram_tiers|^v4_serve_turn|^v4_dec_moe|^v4_dec_trace_start|out of memory'
STATS="V4_SERVE_STATS_LOG=1 DSV4_DECODE_PROF=1 V4_DEC_TRACE=2"

declare -A XENV TREE EST PATHW
XENV[W]="$STATS";                                   TREE[W]=$PROBE;  EST[W]=120;   PATHW[W]=bank
XENV[GB]="$STATS";                                  TREE[GB]=$PROBE; EST[GB]=120;  PATHW[GB]=bank
XENV[U]="$STATS COLI_CUDA_MOE_BATCH_MIN=100000";    TREE[U]=$PROBE;  EST[U]=260;   PATHW[U]=union
XENV[GBn]="$STATS";                                 TREE[GBn]=$PR2;  EST[GBn]=120; PATHW[GBn]=bank
ORDER="W:1 GB:1 U:1 U:2 GB:2 GBn:1 GB:3 U:3 U:4 GB:4 GBn:2 GB:5 U:5 GBn:3"
TMO=900

# probe tree: d0e19de2 + exactly the recorded probe diff, built after it by build_r8.sh
preflight_probe() {
    preflight_tree $PROBE $PR2_SHA 1
    [ -f "$PROBE_DIFF" ] || die_pre "$PROBE_DIFF missing"
    [ "$(sha256sum < "$PROBE_DIFF" | cut -c1-64)" = "$PROBE_DIFF_SHA" ] || die_pre "$PROBE_DIFF is not the recorded diff"
    [ "$(git -C $PROBE diff | sha256sum | cut -c1-64)" = "$PROBE_DIFF_SHA" ] || die_pre "$PROBE diff differs from the recorded one"
    [ "$(git -C $PROBE status --porcelain --untracked-files=no)" = " M c/deepseek_v4.c" ] || die_pre "$PROBE: changes beyond c/deepseek_v4.c"
    head -1 "$(build_log $PROBE)" | grep -q "probe_diff_sha256=$PROBE_DIFF_SHA" || die_pre "build log of $PROBE is not for this diff"
    [ "$(sha256sum $PROBE/c/deepseek_v4 | cut -c1-64)" = "$PROBE_BIN_SHA" ] || die_pre "$PROBE binary is not the recorded build"
    strings $PROBE/c/deepseek_v4 | grep -q 'v4_dec_trace ord=' || die_pre "$PROBE binary has no probe"
    [ "$(sha256sum $PR2/c/deepseek_v4 | cut -c1-64)" = "$PR2_BIN_SHA" ] || die_pre "$PR2 binary is not the final-run binary"
    if strings $PR2/c/deepseek_v4 | grep -q 'v4_dec_trace'; then die_pre "$PR2 binary carries the probe"; fi
}

# COLI_CUDA_MOE_BATCH_MIN: read once, in the bank's per-call gate, and nowhere in the reserve sizing
preflight_min_gate() {
    local src=$1/c/deepseek_v4.c
    [ "$(grep -c 'getenv("COLI_CUDA_MOE_BATCH_MIN")' $src)" = 1 ] || die_pre "COLI_CUDA_MOE_BATCH_MIN read more than once in $src"
    grep -q 'v4_gpu_moe_batch_hint_tokens < minimum) return -1;' $src || die_pre "MOE_BATCH_MIN gate not found in $src"
    grep -q 'coli_v4_gpu_moe_batch_hint(fresh);' $src || die_pre "the prefill hint is not the fresh token count in $src"
    local f body
    for f in v4_gpu_mirror_reserve_size v4_gpu_mirror_reserve_mb; do
        body=$(awk -v f="$f" '$0 ~ "^static [a-z ]*" f "\\(" && $0 ~ /\{$/ {on=1} on {print} on && /^}/ {exit}' $src)
        [ -n "$body" ] || die_pre "$f not found in $src"
        if echo "$body" | grep -qE 'MOE_BATCH_MIN|hint_tokens|minimum'; then die_pre "$f depends on the bank gate"; fi
    done
    [ "$(grep -c 'getenv("COLI_CUDA_MOE_BATCH_MIN")' $1/c/*.cu $1/c/*.h 2>/dev/null | awk -F: '{s+=$NF} END {print s+0}')" = 0 ] \
        || die_pre "COLI_CUDA_MOE_BATCH_MIN read outside deepseek_v4.c"
}

# after each sample: the premises of the comparison; a broken one aborts (the trap restores llama)
check_sample() { # arm k
    local arm=$1 k=$2 d=$OUT/$1/s$2
    local crc reserve bank refill start text ttft chunks
    crc=$(grep '^client_rc=' "$d/sample.txt" | cut -d= -f2)
    reserve=$(grep -ohE 'mirror-reserve=[0-9]+MiB' "$d/serve.log" | tr '\n' ' ')
    bank=$(grep -c 'moe-batch=on bank=' "$d/serve.log")
    refill=$(grep -c 'moe-batch refill ' "$d/serve.log")
    start=$(grep -m1 '^v4_dec_trace_start ' "$d/serve.log" | grep -oE 'bank=[0-9]+ union=[0-9]+ rows=[0-9]+')
    read -r text ttft chunks < <(python3 -c "import json,sys; r=[json.loads(l) for l in open(sys.argv[1]) if l.startswith('{')][0]; print(r['text_sha256'], r['ttft_s'], r['decode_chunks'])" "$d/bench.jsonl" 2>/dev/null)
    log "check $arm s$k: client_rc=$crc reserve='$reserve' bank_lines=$bank refill_lines=$refill prefill_paths='$start' ttft=$ttft chunks=$chunks text=${text:0:12} ref=$([ "$text" = "$REF_TEXT_SHA" ] && echo yes || echo NO) trace_lines=$(grep -c '^v4_dec_trace ' "$d/serve.log") layer_lines=$(grep -c '^v4_dec_layer ' "$d/serve.log") res_lines=$(grep -c '^v4_dec_res ' "$d/serve.log")"
    log "stats $arm s$k: $(grep -h '^v4_serve_turn' "$d/serve.log" | grep -oE 'prompt=[0-9]+ completion=[0-9]+ decode_s=[0-9.]+ tok_s=[0-9.]+ hit=[0-9.]+%' | tr '\n' '|') $(grep -h '^v4_dec_moe' "$d/serve.log" | tail -1 | cut -c1-160)"
    local why=
    [ "$crc" = 0 ] || why="client_rc=$crc"
    [ "$reserve" = "mirror-reserve=3100MiB " ] || why="$why reserve='$reserve' (want one 3100MiB line)"
    if [ "${PATHW[$arm]}" = union ]; then
        [ "$bank" = 0 ] && [ "$refill" = 0 ] || why="$why GPU bank used in $arm (bank_lines=$bank refill_lines=$refill)"
        [[ "$start" =~ ^bank=0\ union=[1-9] ]] || why="$why prefill paths '$start' (want bank=0 union>0)"
    else
        [ "$bank" -ge 1 ] && [ "$refill" -ge 1 ] || why="$why GPU bank not used in $arm (bank_lines=$bank refill_lines=$refill)"
        if [ "${TREE[$arm]}" = "$PROBE" ]; then
            [[ "$start" =~ ^bank=[1-9] ]] || why="$why prefill paths '$start' (want bank>0)"
            [[ "$start" =~ \ union=0\  ]] || log "NOTE: $arm s$k prefill paths '$start': some chunk-layers fell back to the CPU union"
        fi
    fi
    if [ "${TREE[$arm]}" = "$PROBE" ]; then
        [ "$(grep -c '^v4_dec_trace ' "$d/serve.log")" -ge 2 ] || why="$why no per-token probe lines"
    elif grep -qE '^v4_dec_(trace|layer|res) ' "$d/serve.log"; then
        why="$why probe lines from the non-probe binary"
    fi
    if [ -n "$why" ]; then
        log "ABORT after $arm s$k: premise broken:$why"
        exit 8
    fi
    [ "$text" = "$REF_TEXT_SHA" ] || log "NOTE: $arm s$k text ${text:0:12} differs from the reference ${REF_TEXT_SHA:0:12} (a result, not an abort)"
}

# restore llama first, then summarise and pack the evidence (final_common.sh's finish, with this analyzer)
finish_f42v2() {
    restore
    python3 "$FINAL/analyze_f42v2.py" summarize "$OUT" > "$OUT/summary.txt" 2>&1
    tee -a "$OUT/run.log" < "$OUT/summary.txt"
    log "ALL DONE; packing $FINAL/$EXP.tgz"
    tar -C "$FINAL" -czf "$FINAL/$EXP.tgz" "$EXP" && (cd "$FINAL" && sha256sum "$EXP.tgz" > "$EXP.tgz.sha256")
    log "packed $FINAL/$EXP.tgz $(cut -c1-64 "$FINAL/$EXP.tgz.sha256")"
}

lock_or_exit
log "run_f42v2.sh start (pid $$)"
preflight_common bench_f42v2.py bench_common.py bench_pr1.py
grep -q 'f42v2)  *timeout' "$FINAL/final_common.sh" || die_pre "final_common.sh has no f42v2 client"
preflight_tree $PR2 $PR2_SHA
preflight_probe
preflight_switch $PROBE COLI_CUDA_MOE_BATCH COLI_CUDA_MOE_BATCH_MIN V4_SERVE_STATS_LOG DSV4_DECODE_PROF V4_DEC_TRACE
preflight_switch $PR2 COLI_CUDA_MOE_BATCH COLI_CUDA_MOE_BATCH_MIN V4_SERVE_STATS_LOG DSV4_DECODE_PROF
preflight_doc $PR2 COLI_CUDA_MOE_BATCH COLI_CUDA_MOE_BATCH_MIN V4_SERVE_STATS_LOG DSV4_DECODE_PROF
preflight_min_gate $PROBE
preflight_min_gate $PR2
grep -q 'mirror-reserve=' $PROBE/c/deepseek_v4.c || die_pre "no mirror-reserve log line in $PROBE"
grep -q 'fprintf(stderr, "decprof position=' $PROBE/c/deepseek_v4.c || die_pre "no decprof line in $PROBE"
[ "$(usage_state | cut -d' ' -f1)" = "size=0" ] || [ "$(usage_state)" = missing ] \
    || die_pre "$MODEL/.coli_usage is not empty ($(usage_state)): the RAM pins would start from a history"
python3 "$CLIENTS/bench_f42v2.py" --check > /dev/null || die_pre "bench_f42v2.py prompt check failed"
python3 "$FINAL/analyze_f42v2.py" selftest > /dev/null 2>&1 || die_pre "analyze_f42v2.py selftest failed"
total_est=0
for item in $ORDER; do total_est=$((total_est + ${EST[${item%%:*}]})); done
log "plan: $ORDER (estimated $total_est s of samples, cap $MAX_GPU_S s)"
[ $((total_est + 240)) -le "$MAX_GPU_S" ] || die_pre "plan estimate $total_est s exceeds the cap"

if [ "${PREFLIGHT_ONLY:-0}" = 1 ]; then log "PREFLIGHT_ONLY: all checks passed; exiting before llama is touched"; exit 0; fi
arm_trap
capture_meta $PR2 $PROBE
cp "$FINAL/analyze_f42v2.py" "$FINAL/build_r8.sh" "$FINAL/final_common.sh.pre-f42v2" "$OUT/meta/" 2>/dev/null
(cd "$OUT/meta" && sha256sum ./*.sh ./*.py ./*.diff ./*.build.log ./*.pre-f42v2 > sha256s.txt 2>/dev/null)
stop_llama

for item in $ORDER; do
    arm=${item%%:*}; k=${item#*:}
    if over_budget $(est_for $arm ${EST[$arm]}); then log "budget: skipping $arm s$k (GPU window $(gpu_elapsed) s)"; continue; fi
    # shellcheck disable=SC2086
    sample $arm $k ${TREE[$arm]} f42v2 $TMO ${XENV[$arm]}
    check_sample $arm $k
done
finish_f42v2
