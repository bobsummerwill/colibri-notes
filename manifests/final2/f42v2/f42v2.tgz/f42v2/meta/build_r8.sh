#!/bin/bash
# build_r8.sh -- create and CUDA-build the F42 v2 decode-trace probe tree for run_f42v2.sh
# (shadowfax, CPU only: git worktree + nvcc/gcc compile, no GPU use). Same make line as
# final/builds/build_r6.sh and final2/build_r7.sh.
#   r8-pr2-f42probe   d0e19de2 (pr2 tip, = /tmp/cw/r6-pr2) + final2/probe/f42v2_probe_patch.py
#                     (logging only, V4_DEC_TRACE=1|2; see the patch script's docstring)
# Records the probe diff as final2/probe/r8-pr2-f42probe.diff (+ .sha256). Log:
# final2/builds/r8-pr2-f42probe.build.log ("tree=... sha=..." first line, "EXIT=<rc>" last line).
# Refuses to touch an existing tree directory.
set -u
F2=/home/maplemercury/colibri-bench/final2
L=$F2/builds
REPO=/tmp/colibri
T=r8-pr2-f42probe
SHA=d0e19de23c3baf314ee932347c42d5f6d49ef4fb
DIR=/tmp/cw/$T
LOG=$L/$T.build.log
mkdir -p "$L" "$F2/probe"
if [ -e "$DIR" ]; then echo "$DIR exists; not touching it" >&2; exit 1; fi
git -C "$REPO" cat-file -e "$SHA^{commit}" || { echo "$SHA not in $REPO" >&2; exit 1; }
git -C "$REPO" worktree add --detach "$DIR" "$SHA" > /dev/null 2>&1 || { echo "worktree add $DIR failed" >&2; exit 1; }
python3 "$F2/probe/f42v2_probe_patch.py" "$DIR" || { echo "probe patch failed on $DIR" >&2; exit 1; }
git -C "$DIR" diff > "$F2/probe/$T.diff"
sha256sum < "$F2/probe/$T.diff" | cut -c1-64 > "$F2/probe/$T.diff.sha256"
[ "$(git -C "$DIR" status --porcelain --untracked-files=no)" = " M c/deepseek_v4.c" ] || { echo "unexpected changes in $DIR" >&2; exit 1; }
( cd "$DIR/c" && echo "tree=$DIR sha=$(git rev-parse HEAD) start=$(date -Is) probe_diff_sha256=$(cat "$F2/probe/$T.diff.sha256")" && \
  make -f Makefile.deepseek-v4 deepseek-v4 CUDA=1 CUDA_HOME=/usr NVCC=/usr/bin/nvcc CUDA_ARCH=sm_86 NO_TC=1 -j8; \
  echo "EXIT=$? end=$(date -Is)" ) > "$LOG" 2>&1
echo "$T: $(tail -1 "$LOG") binary_sha256=$(sha256sum "$DIR/c/deepseek_v4" 2>/dev/null | cut -c1-64) diff_sha256=$(cat "$F2/probe/$T.diff.sha256")"
echo "BUILD_R8_DONE $(tail -1 "$LOG") $(date -Is)" > "$L/done.r8.$T"
grep -q '^EXIT=0' "$LOG"
