#!/bin/bash
# PR #0 upload race, amplified: provoke the race on upstream dev as hard as this box allows, and
# show the fix end to end (dev drifts across identical cold runs, dev + only the fix does not).
# shadowfax only. Stops llama.cpp ONCE; the EXIT trap ALWAYS restarts it and waits for /health ok.
# Launch (own transient unit, survives an ssh drop):
#   systemd-run --user --unit=colibri-final2-race --collect -p TimeoutStopSec=900 \
#     -p WorkingDirectory=/home/maplemercury/colibri-bench/final2 /bin/bash /home/maplemercury/colibri-bench/final2/run_race.sh
#   options (-E on systemd-run): RACE_PHASE2=on|ifdiff|off (default on: run phase 2 even when the
#   pilot saw nothing, with the fallback setting), RACE_PHASE3=off|on (default off),
#   RACE_PILOT_SETTINGS="L8 S8 Ldef L48 S48 S192", RACE_PILOT_NTOK=120
#   progress: tail /home/maplemercury/colibri-bench/final2/race/run.log
#
# The race (commit cc9c9fab): decode-mirror uploads (upload()) and in-place refills from pageable
# slabs used a legacy-stream cudaMemcpy, not ordered against the non-blocking compute stream; the
# fix queues them on c->stream (h2d()). Triggers named by the commit and used here:
#   DSV4_CUDA_PIN_HOST=0          every refill and upload pageable (legacy-stream copy on dev); all arms
#   DSV4_CUDA_EXPERT_MIRRORS=N    small mirror budget: in-place recycling of nearly every expert of every
#                                 token-layer. dev ignores the cache below 8 entries (all experts on the
#                                 CPU: no GPU MoE, no race), and a layer attaches 6, so 8 is the
#                                 smallest live set; 'def' = unset (capacity 4096, VRAM-bounded)
#   a long first request          RACE_MODE=long: the 1,992-token filler of bench_pr1.py + a long-answer
#                                 question, decoded right after its prefill (on dev/pr0 REAP prefill
#                                 runs on the CPU union: the bank refuses the 132-expert geometry)
#   long decodes                  phase 2 decodes as many tokens (<= 300) as its time budget allows
#   never CUDA_LAUNCH_BLOCKING    (it hides the race; env -i and the summary check it is unset)
#   COLI_CUDA_PIPE=2 stays in COMMON_ENV as in every earlier run, but the deepseek_v4 binary never
#   reads it (only colibri.c does), so it cannot queue work on the V4 compute stream.
# Builds (final2/build_r7.sh; r6-* from final/builds/build_r6.sh), all CUDA=1 sm_86 NO_TC=1:
#   D  /tmp/cw/r6-dev        7b55a9b3 (upstream dev)
#   H  /tmp/cw/r7-devh2d     cc9c9fab = dev + only the upload-ordering commit (its parent is dev)
#   Z  /tmp/cw/r6-pr0        a2c8ba7a (pr0 tip: that commit + the 12 other PR #0 fixes)
#   Dp Hp Zp: /tmp/cw/r6-dev-probe, r7-devh2d-probe, r6-pr0-probe = the same SHAs + the logging-only
#      probe (final2/probe/probe_patch.py, V4_LOGIT_LOG=1: one "v4_logit tok= logit=%a hidden=<FNV-1a
#      of the final hidden row>" line per greedy token, "v4_cpu_moe" for a decode token-layer off the
#      fused GPU path); the probe diff is byte-identical on D and H
# Phase 1 (pilot, dev probe build only, <= 40 min of the window): settings P_<mode><budget>
#   (L = long first request, S = short prompt; budget = DSV4_CUDA_EXPERT_MIRRORS), 2 cold runs each,
#   back to back, RACE_PILOT_NTOK tokens, in priority order; a setting is skipped when its two runs
#   no longer fit in the pilot's 40 min. Default order L8 S8 Ldef L48 S48 S192: budget 8 with and
#   without the long first request, then the default budget (growth uploads through upload(), the
#   regime of the original observation) and 48 after a long request; at ~350 s per long and ~125 s
#   per short run the first four fit (~38 min), S48/S192 only if runs are faster than estimated.
#   Budgets of 8..192 all recycle nearly every expert of every token-layer (5,676 experts, a few
#   percent VRAM hits at most), so 96/192 add little over 48; 'def' is the regime that differs. final_tools.py racepilot compares the two runs' per-token
#   logit lines (and every run against its mode's majority sequence: with >= 8 mirrors every expert is
#   on the GPU whatever the budget, so the budget alone does not change the numbers) and picks the
#   setting with the earliest divergence (ties: more differing lines, then the cheaper short mode);
#   none diverged -> the fallback: the smallest budget with a long first request (L8).
# Phase 2 (<= 90 min): the chosen setting on D, H, Z: 5 cold runs per build, interleaved in rounds
#   (round r: the builds rotated by r-1), rounds 1, 2, 4 on the probe builds and rounds 3, 5 on the
#   plain builds = 3 probe + 2 plain runs per build. Why this split: the probe's per-token logits
#   catch a low-bit drift at its first token, while text changes only when an argmax flips; 3 probe
#   runs give 3 pairwise logit comparisons per build and the >= 3 samples per arm the upstream
#   manifest needs, with exactly one changed variable (engine_commit dev -> H, the same probe diff on
#   both); the probe build's text is the engine's output too, so all 5 texts per build are compared;
#   the 2 plain runs show the unmodified binaries' full-text sha256 (and agree with the probe
#   texts). The decode length is sized from the pilot's timings so the 15 runs fit (<= 300 tokens).
#   Pass criterion (reported, not assumed): dev differs among its own runs (text or logits) while
#   H and Z are bit-identical across all of theirs.
# Phase 3 (RACE_PHASE3=on only, <= 30 min): where the drift was actually seen (10-14, PR #1 benchmark
#   arm C, 2 of 3 runs diverged): the pr1 line just before the fix vs with it, GPU-bank prefill +
#   COLI_CUDA_MOE_DOUBLE=1, the original bench_pr1.py requests (1,992 / 3,005 tokens), probe builds
#   /tmp/cw/r7-p1pre-probe (48767c01) and r7-p1fix-probe (a406901b = 48767c01 + the same h2d change),
#   3 runs each, interleaved. On dev this path does not exist for REAP (the bank refuses 132 experts).
# Output: final2/race/<arm>/s<k>/ (serve.log with the logit lines, bench.jsonl, sample.txt,
# engine_environ.txt, procs.txt, nvsmi.csv, gpu_*.csv, mode.txt), pilot.json, meta/, run.log,
# summary.{txt,json} (incl. manifest_inputs); packed as final2/race.tgz + .sha256.
# Expected GPU window: phase 1 ~38 min, phase 2 ~85-90 min, + ~3 min llama stop/restore = ~2 h 10 min
# (hard cap 2 h 20 min); phase 3 on: + ~25 min (cap + 30 min).

EXP=race
# PREFLIGHT_ONLY=1: run every preflight check (CPU only, nothing stopped or started), log to
# final2/race-preflight/run.log and exit before the EXIT trap exists and before llama is touched
[ "${PREFLIGHT_ONLY:-0}" = 1 ] && EXP=race-preflight
PH1_CAP_S=$((40 * 60))
PH2_CAP_S=$((90 * 60))
PH3_CAP_S=$((30 * 60))
PHASE2=${RACE_PHASE2:-on}
PHASE3=${RACE_PHASE3:-off}
PILOT_SETTINGS=${RACE_PILOT_SETTINGS:-"L8 S8 Ldef L48 S48 S192"}
PILOT_N=${RACE_PILOT_NTOK:-120}
MAX_GPU_S=$(( PH1_CAP_S + PH2_CAP_S + 600 ))
[ "$PHASE3" = on ] && MAX_GPU_S=$(( MAX_GPU_S + PH3_CAP_S ))
NVSMI_MS=5000
source /home/maplemercury/colibri-bench/final2/final_common.sh

DEV_SHA=7b55a9b3792527f52d1a2337fd9e312b9a7983e3
H_SHA=cc9c9fab4d7d0e8c962d38a7ffb8c752a6458505
PR0_SHA=a2c8ba7a149a31a781e84a992aa980afdb93497d
P1PRE_SHA=48767c016c993e59cd74f5511983be7bb65ec791
P1FIX_SHA=a406901b2c256499ed02140c8d10aa34aa00b1eb
DEV=/tmp/cw/r6-dev;        DEVP=/tmp/cw/r6-dev-probe
H=/tmp/cw/r7-devh2d;       HP=/tmp/cw/r7-devh2d-probe
PR0=/tmp/cw/r6-pr0;        PR0P=/tmp/cw/r6-pr0-probe
Q=/tmp/cw/r7-p1pre-probe;  F=/tmp/cw/r7-p1fix-probe
MODE_RE='moe-batch=|moe-double|mirror-reserve|mirror-cache:|DSV4 CUDA\] device|out of memory'
TRIG="DSV4_CUDA_PIN_HOST=0"
declare -A MODE_EST=([long]=380 [short]=170)   # pilot sample estimates (s), replaced by measured ones

lock_or_exit
log "run_race.sh start (pid $$) RACE_PHASE2=$PHASE2 RACE_PHASE3=$PHASE3 pilot='$PILOT_SETTINGS' x2 at $PILOT_N tokens"
case "$PHASE2" in on|ifdiff|off) ;; *) die_pre "RACE_PHASE2=$PHASE2 (on|ifdiff|off)" ;; esac
case "$PHASE3" in on|off) ;; *) die_pre "RACE_PHASE3=$PHASE3 (on|off)" ;; esac
[ "$PILOT_N" -ge 20 ] 2>/dev/null && [ "$PILOT_N" -le 300 ] || die_pre "RACE_PILOT_NTOK=$PILOT_N (20..300)"
for s in $PILOT_SETTINGS; do
    [[ "$s" =~ ^[LS](def|[0-9]+)$ ]] || die_pre "pilot setting $s (want L|S + budget or def)"
    b=${s:1}; [ "$b" = def ] || [ "$b" -ge 8 ] || die_pre "pilot budget $b < 8: dev keeps every expert on the CPU below 8 mirrors"
done
preflight_common bench_race.py bench_common.py bench_pr1.py bench_decode.py
preflight_tree $DEV $DEV_SHA
preflight_tree $H $H_SHA
preflight_tree $PR0 $PR0_SHA
[ "$(git -C $H rev-parse HEAD^)" = $DEV_SHA ] || die_pre "$H is not a child of dev"
[ "$(git -C $H diff --name-only $DEV_SHA HEAD)" = "c/backend_cuda_dsv4.cu" ] || die_pre "$H changes more than c/backend_cuda_dsv4.cu"
probe_tree_ok $DEVP $DEV_SHA || die_pre "probe tree $DEVP not usable"
probe_tree_ok $HP $H_SHA || die_pre "probe tree $HP not usable"
probe_tree_ok $PR0P $PR0_SHA || die_pre "probe tree $PR0P not usable"
cmp -s "$FINAL/probe/r6-dev-probe.diff" "$FINAL/probe/r7-devh2d-probe.diff" || die_pre "dev and dev+h2d probe diffs differ"
for t in $DEV $H $PR0 $DEVP $HP $PR0P; do
    preflight_switch $t DSV4_CUDA_PIN_HOST DSV4_CUDA_EXPERT_MIRRORS
    grep -q 'if (cache->capacity < 8) return -1;' $t/c/deepseek_v4.c || die_pre "$t: mirror minimum is not 8"
done
for t in $DEVP $HP $PR0P; do preflight_switch $t V4_LOGIT_LOG; done
preflight_doc $DEV DSV4_CUDA_PIN_HOST DSV4_CUDA_EXPERT_MIRRORS
grep -q 'cudaMemcpy(t->w,w,wb,cudaMemcpyHostToDevice),"refill weight upload"' $DEV/c/backend_cuda_dsv4.cu || die_pre "dev has no legacy refill copy"
grep -q 'static int h2d(Dev\*c' $H/c/backend_cuda_dsv4.cu || die_pre "$H has no h2d()"
grep -q 'static int h2d(Dev\*c' $PR0/c/backend_cuda_dsv4.cu || die_pre "$PR0 has no h2d()"
TREES="$DEV $H $PR0 $DEVP $HP $PR0P"
if [ "$PHASE3" = on ]; then
    probe_tree_ok $Q $P1PRE_SHA || die_pre "probe tree $Q not usable"
    probe_tree_ok $F $P1FIX_SHA || die_pre "probe tree $F not usable"
    [ "$(git -C $F rev-parse HEAD^)" = $P1PRE_SHA ] || die_pre "$F is not a child of $P1PRE_SHA"
    for t in $Q $F; do preflight_switch $t COLI_CUDA_MOE_DOUBLE V4_LOGIT_LOG; done
    cmp -s "$FINAL/probe/r7-p1pre-probe.diff" "$FINAL/probe/r7-p1fix-probe.diff" || die_pre "phase-3 probe diffs differ"
    TREES="$TREES $Q $F"
fi

if [ "${PREFLIGHT_ONLY:-0}" = 1 ]; then log "PREFLIGHT_ONLY: all checks passed; exiting before llama is touched"; exit 0; fi
arm_trap
# shellcheck disable=SC2086
capture_meta $TREES
stop_llama

# ---------------- phase 1: pilot on the dev probe build
P1_T0=$(gpu_elapsed)
for s in $PILOT_SETTINGS; do
    case ${s:0:1} in L) mode=long ;; *) mode=short ;; esac
    b=${s:1}
    envs="$TRIG V4_LOGIT_LOG=1"; [ "$b" = def ] || envs="$envs DSV4_CUDA_EXPERT_MIRRORS=$b"
    est=${MODE_EST[$mode]}      # the last measured sample of this mode (pilot defaults before)
    if [ $(( $(gpu_elapsed) - P1_T0 + 2 * est )) -gt $PH1_CAP_S ] || over_budget $(( 2 * est )); then
        log "pilot budget: skipping $s (two runs of ~${est}s do not fit; pilot at $(( $(gpu_elapsed) - P1_T0 ))s of ${PH1_CAP_S}s)"
        continue
    fi
    for k in 1 2; do
        # shellcheck disable=SC2086
        sample P_$s $k $DEVP race:$mode:$PILOT_N $(( est * 3 + 300 )) $envs
        MODE_EST[$mode]=${LAST_ARM_S[P_$s]}
        log "P_$s s$k: $(grep -c '^v4_logit ' "$OUT/P_$s/s$k/serve.log") logit lines, $(grep -c '^v4_cpu_moe ' "$OUT/P_$s/s$k/serve.log") cpu-moe lines, GPU0 max $(python3 -c "import sys; sys.path.insert(0,'$FINAL'); import final_tools as t; print(t.gpu_max('$OUT/P_$s/s$k'))") MiB"
    done
done
PILOT=$(python3 "$FINAL/final_tools.py" racepilot "$OUT" 2>&1)
echo "$PILOT" | sed 's/^/pilot: /' | tee -a "$OUT/run.log"
pv() { echo "$PILOT" | sed -n "s/^$1=//p" | head -1; }
CHOSEN=$(pv CHOSEN); CMODE=$(pv CHOSEN_MODE); CBUDGET=$(pv CHOSEN_BUDGET); RESULT=$(pv PILOT_RESULT)
FIRSTD=$(pv FIRST_DIFF_LINE); TTFT_S=$(pv TTFT_S); SPT_MS=$(pv SPT_MS); OVER_S=$(pv OVERHEAD_S); READY_S=$(pv READY_S)
case "$CMODE" in long|short) ;; *) CMODE=long ;; esac
[[ "$CBUDGET" =~ ^(def|[0-9]+)$ ]] || CBUDGET=8
for v in TTFT_S SPT_MS OVER_S READY_S; do [ "${!v}" -ge 0 ] 2>/dev/null || eval "$v=0"; done
[ "$TTFT_S" -gt 0 ] || TTFT_S=$([ $CMODE = long ] && echo 230 || echo 5)
[ "$SPT_MS" -gt 0 ] || SPT_MS=1000
[ "$OVER_S" -gt 0 ] || OVER_S=30
[ "$FIRSTD" -ge -1 ] 2>/dev/null || FIRSTD=-1
log "phase 1 done at GPU window $(gpu_elapsed)s: chosen=$CHOSEN mode=$CMODE budget=$CBUDGET result=$RESULT first_diff_line=$FIRSTD ttft=${TTFT_S}s spt=${SPT_MS}ms overhead=${OVER_S}s ready=${READY_S}s"

# ---------------- phase 2: D / H / Z with the chosen setting
RUN2=1
[ "$PHASE2" = off ] && RUN2=0
[ "$PHASE2" = ifdiff ] && [ "$RESULT" = NODIFF ] && RUN2=0
if [ $RUN2 = 0 ]; then
    log "phase 2: not run (RACE_PHASE2=$PHASE2, pilot $RESULT)"
else
    P3_RES=0; [ "$PHASE3" = on ] && P3_RES=$PH3_CAP_S
    REM2=$(( MAX_GPU_S - $(gpu_elapsed) - 240 - P3_RES ))
    [ $REM2 -gt $PH2_CAP_S ] && REM2=$PH2_CAP_S
    FIXED=$(( OVER_S + READY_S + TTFT_S + 15 ))
    N2=$(( (REM2 / 15 - FIXED) * 1000 * 100 / (SPT_MS * 115) ))
    if [ "$RESULT" = NODIFF ]; then NLO=120; else NLO=$(( 2 * FIRSTD + 10 )); [ $NLO -lt 40 ] && NLO=40; [ $NLO -gt 120 ] && NLO=120; fi
    [ $N2 -lt $NLO ] && { log "phase 2: only $N2 tokens fit 15 runs in ${REM2}s; using $NLO (the last runs may be skipped)"; N2=$NLO; }
    [ $N2 -gt 300 ] && N2=300
    EST2=$(( FIXED + N2 * SPT_MS * 115 / 100000 ))
    TMO2=$(( EST2 * 2 + 120 ))
    P2_T0=$(gpu_elapsed)
    ENV2="$TRIG"; [ "$CBUDGET" = def ] || ENV2="$ENV2 DSV4_CUDA_EXPERT_MIRRORS=$CBUDGET"
    log "phase 2: setting $CHOSEN ($CMODE, budget $CBUDGET), $N2 tokens per run, ~${EST2}s per run, budget ${REM2}s, env '$ENV2'"
    declare -A PLAIN_TREE=([D]=$DEV [H]=$H [Z]=$PR0) PROBE_TREE=([D]=$DEVP [H]=$HP [Z]=$PR0P)
    declare -A NPLAIN=([D]=0 [H]=0 [Z]=0) NPROBE=([D]=0 [H]=0 [Z]=0)
    for r in 1 2 3 4 5; do
        case $r in 3|5) kind=plain ;; *) kind=probe ;; esac
        for b in $(rotate $((r - 1)) D H Z); do
            if [ $(( $(gpu_elapsed) - P2_T0 + EST2 )) -gt $REM2 ] || over_budget $(( EST2 + P3_RES )); then
                log "phase 2 budget: skipping round $r $b ($kind) at GPU window $(gpu_elapsed)s"; continue
            fi
            if [ $kind = probe ]; then
                NPROBE[$b]=$(( NPROBE[$b] + 1 ))
                # shellcheck disable=SC2086
                sample ${b}p ${NPROBE[$b]} ${PROBE_TREE[$b]} race:$CMODE:$N2 $TMO2 $ENV2 V4_LOGIT_LOG=1
                log "${b}p s${NPROBE[$b]}: $(grep -c '^v4_logit ' "$OUT/${b}p/s${NPROBE[$b]}/serve.log") logit lines, $(grep -c '^v4_cpu_moe ' "$OUT/${b}p/s${NPROBE[$b]}/serve.log") cpu-moe lines"
            else
                NPLAIN[$b]=$(( NPLAIN[$b] + 1 ))
                # shellcheck disable=SC2086
                sample $b ${NPLAIN[$b]} ${PLAIN_TREE[$b]} race:$CMODE:$N2 $TMO2 $ENV2
            fi
        done
    done
fi

# ---------------- phase 3 (optional): the pr1-line path where the drift was seen
if [ "$PHASE3" = on ]; then
    P3_T0=$(gpu_elapsed)
    declare -A P3_TREE=([Qp]=$Q [Fp]=$F)
    EST3=280
    for k in 1 2 3; do
        for a in $(rotate $((k - 1)) Qp Fp); do
            est=$(est_for $a $EST3)
            if [ $(( $(gpu_elapsed) - P3_T0 + est )) -gt $PH3_CAP_S ] || over_budget $est; then
                log "phase 3 budget: skipping $a s$k"; continue
            fi
            sample $a $k ${P3_TREE[$a]} pr1:both 900 COLI_CUDA_MOE_DOUBLE=1 V4_LOGIT_LOG=1
            log "$a s$k: $(grep -c '^v4_logit ' "$OUT/$a/s$k/serve.log") logit lines; $(grep -hoE 'moe-double=[a-z]+|moe-batch=on bank=[0-9]+-experts' "$OUT/$a/s$k/serve.log" | sort -u | tr '\n' ' ')"
        done
    done
fi
finish race
