#!/usr/bin/env python3
"""F42 v2 client (run_f42v2.sh): bench_pr1.py's first request, exactly, with per-chunk times.

One streamed greedy request to one cold server, one JSON line (bench_common.stream: full text,
sha256, per-chunk arrival times as offsets from the request start, t0_epoch to align with the
serve log's wall= stamps and nvidia-smi):
  long_prefill  bench_pr1.py REQUESTS[0]: the 1,992-token prompt (filler + "Summarize the above
                in one sentence.") and max_tokens 100, read from bench_pr1.py's source with ast
                (filler, filler2 and REQUESTS evaluated with no builtins but range, never
                imported or run) and checked against fixed sha256s. The request body is
                bench_pr1.py's (same JSON keys, order and values). Greedy decoding ends this
                answer with EOS after 24 content chunks (reference text 32534c06..., the final
                PR #1 benchmark: identical on dev's CPU-union and pr1's GPU-bank prefill).
usage: bench_f42v2.py OUT.jsonl            (bench_f42v2.py --check: verify the prompt only)
"""
import ast, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bench_common as bc

PROMPT_SHA256 = "e13a02a377c208b8eac583aa2a52ef82ab5ebff96a0c2e9bbf8c08954e97ca4d"
REF_TEXT_SHA256 = "32534c06abd640d59d2eb39ab6609051f63e9876f533aad1d75dd5cd775835ba"
NAME, MAX_TOKENS, PROMPT_TOKENS = "long_prefill", 100, 1992


def first_request():
    path = os.path.join(bc.HERE, "bench_pr1.py")
    ns = {"__builtins__": {"range": range}}
    for node in ast.parse(open(path).read()).body:
        if isinstance(node, ast.Assign) and [getattr(t, "id", None) for t in node.targets] in (
                ["filler"], ["filler2"], ["REQUESTS"]):
            name = node.targets[0].id
            ns[name] = eval(compile(ast.Expression(node.value), "bench_pr1.py:" + name, "eval"), ns)
    if bc.sha(ns["filler"]) != bc.FILLER_SHA256:
        raise SystemExit("bench_pr1.py filler changed: %s" % bc.sha(ns["filler"]))
    name, prompt, max_tokens, prompt_tokens = ns["REQUESTS"][0]
    if (name, max_tokens, prompt_tokens) != (NAME, MAX_TOKENS, PROMPT_TOKENS) or bc.sha(prompt) != PROMPT_SHA256:
        raise SystemExit("bench_pr1.py REQUESTS[0] changed: %r %r %r %s" % (name, max_tokens, prompt_tokens, bc.sha(prompt)))
    return name, prompt, max_tokens


def main():
    name, prompt, max_tokens = first_request()
    if sys.argv[1:] == ["--check"]:
        print("ok", name, max_tokens, bc.sha(prompt))
        return
    with open(sys.argv[1], "w") as f:
        rec = bc.stream(name, prompt, max_tokens)
        rec["ref_text_sha256"] = REF_TEXT_SHA256
        rec["text_is_ref"] = rec["text_sha256"] == REF_TEXT_SHA256
        bc.write(f, rec)


if __name__ == "__main__":
    main()
