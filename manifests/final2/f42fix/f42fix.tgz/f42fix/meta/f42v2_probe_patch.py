#!/usr/bin/env python3
"""F42 v2 decode-trace probe (logging only, no numeric change) for the pr2 tip d0e19de2.

Applies, to <tree>/c/deepseek_v4.c, stderr diagnostics gated by V4_DEC_TRACE (unset or 0 =
off: the only always-on change is three counter increments in the batched block):

  v4_dec_trace_start ord=1 ...   once per request, at its first token (ordinal 1, emitted by
      the prefill): which MoE path the batched (prefill) chunk-layers took so far (process
      totals: bank = GPU expert bank, union = CPU union, rows = per-row fallback), the
      expert store's process totals (requests/hits/misses/bytes_read/...) and disk/wait
      seconds, and the decode MoE totals before this request's decode.
  v4_dec_res tag=decode-start layer=L ...   right after that line, one line per layer: the
      RAM tier of the expert store at decode start, read under the store mutex: every
      resident expert as id:usage:age[p] (usage = the hot policy's selection count,
      age = store clock minus the slot's last use, p = an active pin), the pin ranking,
      and the layer's request count.
  v4_dec_trace ord=K ...   one line per emitted token (K = 1, 2, ...): wall/monotonic time and,
      cumulative from ordinal 1 (so ordinal K covers the first K-1 decode forwards), the
      decode MoE counters of V4_SERVE_STATS_LOG's v4_dec_moe line (calls, total_s,
      fetch_wait_s, attach_s, uploads, gpu_s, store_fetches) and the expert store's
      requests / hits / misses (SSD reads) / bytes_read / prefetched, disk_s and wait_s.
  v4_dec_layer ord=K layer=L ...   one line per decode token-layer (V4_DEC_TRACE=2), or only
      for the first decode forward (ord=1, V4_DEC_TRACE=1): the routed expert ids and that
      token-layer's store requests/hits/misses/bytes and uploads, fetch-wait, attach and
      MoE wall ms. ord=1 hits = how many of the first decode token's routed experts were
      RAM-resident (the residency snapshot).

Every value is a counter or state the engine already keeps; the probe reads them (the
store's own stats() and getters, which take the store mutex as v4_serve_finish does) and
writes stderr. No engine state is written except the probe's own globals.
usage: f42v2_probe_patch.py <tree>"""
import os, sys

tree = sys.argv[1]
p = os.path.join(tree, "c", "deepseek_v4.c")
s = open(p).read()
if "DEBUG ONLY (F42 decode trace" in s:
    sys.exit("already patched")

EDITS = []

# 1. BLOCK_HYBRID unit: the probe's globals next to the decode MoE counters.
EDITS.append(("""/* Decode MoE counters (V4_SERVE_STATS_LOG; deepseek_v4_internal.h). */
int g_v4_dec_counting;
unsigned long long g_v4_dec_calls, g_v4_dec_uploads;
double g_v4_dec_total_s, g_v4_dec_fetch_s, g_v4_dec_attach_s, g_v4_dec_gpu_s;
unsigned long long g_v4_gpu_first_hits, g_v4_dec_store_fetches;
""", """/* Decode MoE counters (V4_SERVE_STATS_LOG; deepseek_v4_internal.h). */
int g_v4_dec_counting;
unsigned long long g_v4_dec_calls, g_v4_dec_uploads;
double g_v4_dec_total_s, g_v4_dec_fetch_s, g_v4_dec_attach_s, g_v4_dec_gpu_s;
unsigned long long g_v4_gpu_first_hits, g_v4_dec_store_fetches;
/* DEBUG ONLY (F42 decode trace, V4_DEC_TRACE): logging-only state, read by the
 * serve unit. g_v4_dec_trace_ord: ordinal of the token the serve callback
 * emitted last (the next decode forward consumes it); the chunk counters say
 * which MoE path each batched (prefill) chunk-layer took. */
int g_v4_dec_trace_ord = -1;
unsigned long long g_v4_dec_trace_bank_chunks, g_v4_dec_trace_union_chunks,
                   g_v4_dec_trace_rows_chunks;
static int v4_dec_trace_level(void) {
    static int level = -1;
    if (level < 0) {
        const char *setting = getenv("V4_DEC_TRACE");
        level = setting ? atoi(setting) : 0;
        if (level < 0) level = 0;
    }
    return level;
}
"""))

# 2. moe_token_pipeline entry: the token-layer's store counters before it.
EDITS.append(("""    /* decode MoE counters (deepseek_v4_internal.h): the routing included */
    int dec = g_v4_dec_counting;
    double dec_t0 = v4_wait_clock();
#endif
""", """    /* decode MoE counters (deepseek_v4_internal.h): the routing included */
    int dec = g_v4_dec_counting;
    double dec_t0 = v4_wait_clock();
    /* DEBUG ONLY (F42 decode trace): this token-layer's counters before it */
    int trace_layer = dec && store && store->ops && store->ops->stats &&
        (v4_dec_trace_level() >= 2 ||
         (v4_dec_trace_level() == 1 && g_v4_dec_trace_ord == 1));
    ColiExpertStoreStats trace_s0;
    memset(&trace_s0, 0, sizeof(trace_s0));
    double trace_f0 = g_v4_dec_fetch_s, trace_a0 = g_v4_dec_attach_s;
    double trace_t0 = g_v4_dec_total_s;
    unsigned long long trace_u0 = g_v4_dec_uploads;
    if (trace_layer) store->ops->stats(store, &trace_s0);
#endif
"""))

# 3. moe_token_pipeline exit (lanes finished, leases released): one line per token-layer.
EDITS.append(("""    if (dec) {
        g_v4_dec_total_s += v4_wait_clock() - dec_t0;
        g_v4_dec_calls++;
    }
""", """    if (dec) {
        g_v4_dec_total_s += v4_wait_clock() - dec_t0;
        g_v4_dec_calls++;
    }
    if (trace_layer) {   /* DEBUG ONLY (F42 decode trace): one line per decode token-layer */
        ColiExpertStoreStats trace_s1;
        memset(&trace_s1, 0, sizeof(trace_s1));
        store->ops->stats(store, &trace_s1);
        char trace_routed[192];
        int trace_at = 0;
        trace_routed[0] = 0;
        for (int i = 0; expert_ids && i < selected &&
                        trace_at < (int)sizeof(trace_routed) - 16; i++)
            trace_at += snprintf(trace_routed + trace_at,
                                 sizeof(trace_routed) - (size_t)trace_at,
                                 "%s%d", i ? "," : "", expert_ids[i]);
        fprintf(stderr, "v4_dec_layer ord=%d layer=%d routed=%s req=%llu hits=%llu "
                "misses=%llu bytes=%llu uploads=%llu fetch_ms=%.3f attach_ms=%.3f "
                "total_ms=%.3f\\n",
                g_v4_dec_trace_ord, weights->plan.layer, trace_routed,
                (unsigned long long)(trace_s1.requests - trace_s0.requests),
                (unsigned long long)(trace_s1.hits - trace_s0.hits),
                (unsigned long long)(trace_s1.misses - trace_s0.misses),
                (unsigned long long)(trace_s1.bytes_read - trace_s0.bytes_read),
                g_v4_dec_uploads - trace_u0,
                (g_v4_dec_fetch_s - trace_f0) * 1e3,
                (g_v4_dec_attach_s - trace_a0) * 1e3,
                (g_v4_dec_total_s - trace_t0) * 1e3);
    }
"""))

# 4. Batched block: count which MoE path each chunk-layer took (the same branches, braced).
EDITS.append(("""    if (!result && batch > 1 &&
        coli_v4_gpu_moe_batch_union(ffn_branch, weights, config, experts,
                                    ffn_normalized, tokens, batch) == 0)
        coli_bf16_round_array(ffn_branch, (size_t)batch * d);
    else
#endif
    if (!result && batch > 1 && v4_expert_union_enabled())
        result = v4_moe_batch_union(
            ffn_branch, weights, config, experts,
            ffn_normalized, tokens, batch);
    else
        for (int item = 0; !result && item < batch; item++)
            result = moe_token_pipeline(
                ffn_branch + (size_t)item * d, weights, config, experts,
                ffn_normalized + (size_t)item * d, tokens[item]);
""", """    if (!result && batch > 1 &&
        coli_v4_gpu_moe_batch_union(ffn_branch, weights, config, experts,
                                    ffn_normalized, tokens, batch) == 0) {
        coli_bf16_round_array(ffn_branch, (size_t)batch * d);
        g_v4_dec_trace_bank_chunks++;    /* DEBUG ONLY (F42 decode trace): a count */
    } else
#endif
    if (!result && batch > 1 && v4_expert_union_enabled()) {
        result = v4_moe_batch_union(
            ffn_branch, weights, config, experts,
            ffn_normalized, tokens, batch);
        g_v4_dec_trace_union_chunks++;   /* DEBUG ONLY (F42 decode trace): a count */
    } else {
        if (!result) g_v4_dec_trace_rows_chunks++;   /* DEBUG ONLY (F42 decode trace) */
        for (int item = 0; !result && item < batch; item++)
            result = moe_token_pipeline(
                ffn_branch + (size_t)item * d, weights, config, experts,
                ffn_normalized + (size_t)item * d, tokens[item]);
    }
"""))

# 5. HOT_ROWS16 store unit: read-only dump of the RAM tier (after prefill_pool, same unit).
EDITS.append(("""void coli_v4_expert_store_prefill_pool(ColiExpertStore *store, int layer) {
    if (!store || !store->state || store->gpu || !hot_find(store)) return;
    V4ExpertStoreState *state = store->state;
    if (layer < 0 || layer >= state->layers) layer = -1;
    pthread_mutex_lock(&state->mutex);
    state->pool_layer = layer;
    pthread_mutex_unlock(&state->mutex);
}
""", """void coli_v4_expert_store_prefill_pool(ColiExpertStore *store, int layer) {
    if (!store || !store->state || store->gpu || !hot_find(store)) return;
    V4ExpertStoreState *state = store->state;
    if (layer < 0 || layer >= state->layers) layer = -1;
    pthread_mutex_lock(&state->mutex);
    state->pool_layer = layer;
    pthread_mutex_unlock(&state->mutex);
}

/* DEBUG ONLY (F42 decode trace, V4_DEC_TRACE): the RAM tier of every layer at
 * one moment, read under the store mutex, nothing written. One line per layer:
 * each resident expert as id:usage:age (usage = the hot policy's selection
 * count, age = store clock minus the slot's last use; a trailing p = an active
 * pin), the pin ranking (-1 = empty rank) and the layer's request count. */
void coli_v4_dec_trace_residency(ColiExpertStore *store, const char *tag) {
    V4HotPolicy *policy = store && store->state ? hot_find(store) : NULL;
    if (!policy) {
        fprintf(stderr, "v4_dec_res tag=%s no-hot-policy\\n", tag);
        return;
    }
    V4ExpertStoreState *state = store->state;
    size_t cap = 256 + (size_t)state->experts_per_layer * 40 +
                 (size_t)(policy->pin_count > 0 ? policy->pin_count : 0) * 8;
    char *line = malloc(cap);
    if (!line) return;
    pthread_mutex_lock(&state->mutex);
    for (int layer = 0; layer < state->layers; layer++) {
        size_t at = 0;
        int resident = 0, pinned = 0;
        const uint64_t *usage = policy->usage +
            (size_t)layer * state->experts_per_layer;
#define RES_PUT(...) do { if (at < cap) { int n_ = snprintf(line + at, cap - at, __VA_ARGS__); \\
                              if (n_ > 0) at += (size_t)n_; } } while (0)
        RES_PUT("v4_dec_res tag=%s layer=%d lreq=%llu clock=%llu res=", tag, layer,
                (unsigned long long)policy->layer_requests[layer],
                (unsigned long long)state->clock);
        for (int expert = 0; expert < state->experts_per_layer; expert++) {
            V4ExpertSlot *slot = indexed_expert_slot(state, (ColiExpertKey){layer, expert});
            if (!slot || !slot->slab || slot->expert != expert) continue;
            int is_pin = hot_is_pinned(policy, layer, expert);
            RES_PUT("%s%d:%llu:%llu%s", resident ? "," : "", expert,
                    (unsigned long long)usage[expert],
                    (unsigned long long)(state->clock - slot->used), is_pin ? "p" : "");
            resident++;
            pinned += is_pin;
        }
        RES_PUT(" n=%d pinned_resident=%d pins=", resident, pinned);
        for (int rank = 0; rank < policy->pin_count; rank++)
            RES_PUT("%s%d", rank ? "," : "",
                    policy->pins[(size_t)layer * policy->pin_count + rank]);
#undef RES_PUT
        if (at >= cap) at = cap - 1;
        line[at] = 0;
        fprintf(stderr, "%s\\n", line);
    }
    pthread_mutex_unlock(&state->mutex);
    free(line);
}
"""))

# 6. Serve token callback: one line per emitted token (after its DATA frame is written).
EDITS.append(("""            v4_serve_data(stdout, stream->request_id, piece, bytes);
    }
    stream->tail[0] = 0;
""", """            v4_serve_data(stdout, stream->request_id, piece, bytes);
    }
    {   /* DEBUG ONLY (F42 decode trace, V4_DEC_TRACE=1|2): one line per emitted
         * token, cumulative from this request's first token (ordinal 1, from
         * the prefill): the decode MoE counters of v4_dec_moe and the expert
         * store's own counters. At ordinal 1 also the prefill's MoE paths and
         * the RAM tier (v4_dec_res). Reads counters only, writes stderr. */
        extern int g_v4_dec_trace_ord;
        extern unsigned long long g_v4_dec_trace_bank_chunks,
            g_v4_dec_trace_union_chunks, g_v4_dec_trace_rows_chunks;
        void coli_v4_dec_trace_residency(ColiExpertStore *store, const char *tag);
        static int trace_level = -1;
        static ColiExpertStoreStats ts0;
        static double tt0, tf0, ta0, tg0, ttot0, tdisk0, twait0;
        static unsigned long long tc0, tu0, tsf0;
        if (trace_level < 0) {
            const char *setting = getenv("V4_DEC_TRACE");
            trace_level = setting ? atoi(setting) : 0;
        }
        g_v4_dec_trace_ord = ordinal;
        if (trace_level > 0) {
            ColiExpertStore *experts = stream->session && stream->session->engine
                ? stream->session->engine->experts : NULL;
            ColiExpertStoreStats ts;
            memset(&ts, 0, sizeof(ts));
            if (experts && experts->ops && experts->ops->stats)
                experts->ops->stats(experts, &ts);
            double tdisk = experts ? coli_v4_expert_store_disk_sec(experts) : 0.0;
            double twait = experts ? coli_v4_expert_store_wait_sec(experts) : 0.0;
            double tnow = spec_now();
            struct timespec twall;
            clock_gettime(CLOCK_REALTIME, &twall);
            double twall_s = (double)twall.tv_sec + twall.tv_nsec * 1e-9;
            if (ordinal == 1) {
                ts0 = ts; tt0 = tnow; tdisk0 = tdisk; twait0 = twait;
                tf0 = g_v4_dec_fetch_s; ta0 = g_v4_dec_attach_s;
                tg0 = g_v4_dec_gpu_s; ttot0 = g_v4_dec_total_s;
                tc0 = g_v4_dec_calls; tu0 = g_v4_dec_uploads;
                tsf0 = g_v4_dec_store_fetches;
                fprintf(stderr, "v4_dec_trace_start ord=1 pos=%d wall=%.4f "
                        "prefill_moe_chunk_layers bank=%llu union=%llu rows=%llu "
                        "store_total req=%llu hits=%llu misses=%llu bytes=%llu "
                        "prefetched=%llu prefetch_hits=%llu resident_bytes=%llu "
                        "capacity_bytes=%llu disk_s=%.3f wait_s=%.3f "
                        "dec_moe_total calls=%llu uploads=%llu (process totals)\\n",
                        position, twall_s, g_v4_dec_trace_bank_chunks,
                        g_v4_dec_trace_union_chunks, g_v4_dec_trace_rows_chunks,
                        (unsigned long long)ts.requests, (unsigned long long)ts.hits,
                        (unsigned long long)ts.misses, (unsigned long long)ts.bytes_read,
                        (unsigned long long)ts.prefetched,
                        (unsigned long long)ts.prefetch_hits,
                        (unsigned long long)ts.resident_bytes,
                        (unsigned long long)ts.capacity_bytes, tdisk, twait,
                        g_v4_dec_calls, g_v4_dec_uploads);
                coli_v4_dec_trace_residency(experts, "decode-start");
            }
            fprintf(stderr, "v4_dec_trace ord=%d pos=%d tok=%d t=%.4f wall=%.4f "
                    "calls=%llu total_s=%.4f fetch_wait_s=%.4f attach_s=%.4f "
                    "uploads=%llu gpu_s=%.4f store_fetches=%llu req=%llu hits=%llu "
                    "misses=%llu bytes=%llu prefetched=%llu disk_s=%.4f wait_s=%.4f\\n",
                    ordinal, position, token, tnow - tt0, twall_s,
                    g_v4_dec_calls - tc0, g_v4_dec_total_s - ttot0,
                    g_v4_dec_fetch_s - tf0, g_v4_dec_attach_s - ta0,
                    g_v4_dec_uploads - tu0, g_v4_dec_gpu_s - tg0,
                    g_v4_dec_store_fetches - tsf0,
                    (unsigned long long)(ts.requests - ts0.requests),
                    (unsigned long long)(ts.hits - ts0.hits),
                    (unsigned long long)(ts.misses - ts0.misses),
                    (unsigned long long)(ts.bytes_read - ts0.bytes_read),
                    (unsigned long long)(ts.prefetched - ts0.prefetched),
                    tdisk - tdisk0, twait - twait0);
        }
    }
    stream->tail[0] = 0;
"""))

for old, new in EDITS:
    n = s.count(old)
    if n != 1:
        sys.exit(f"anchor count {n} != 1 in {p}: {old.splitlines()[0]!r}")
    s = s.replace(old, new)
open(p, "w").write(s)
print("patched", p)
