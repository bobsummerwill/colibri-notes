#!/usr/bin/env python3
"""Summary of run_f42v2.sh (F42 v2: decode right after a GPU-bank vs a CPU-union prefill on
IDENTICAL text, equal 3100 MiB mirror reserve). CPU only; reads final2/f42v2/<arm>/s<k>/.

  analyze_f42v2.py summarize DIR   writes DIR/summary.json, prints a readable summary
  analyze_f42v2.py selftest        runs the summary on synthetic samples (run_f42v2.sh preflight)

Arms: W (warm-up, GB config, discarded), GB (probe build, GPU-bank prefill), U (probe build,
GB + COLI_CUDA_MOE_BATCH_MIN=100000: CPU union, same reserve), GBn (GB on the non-probe r6-pr2
binary: probe overhead / text check). Probe lines (f42v2_probe_patch.py): v4_dec_trace_start,
v4_dec_res, v4_dec_trace (one per emitted token, cumulative from ordinal 1), v4_dec_layer.
H1 prediction: on identical text, GB-U = extra fetch_wait (more RAM misses = SSD reads)
concentrated in the first decode tokens, uploads ~equal, attach ~equal.
"""
import json, os, re, statistics, sys, tempfile, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import final_tools as ft

REF_TEXT = ft.REF_PR1["long_prefill"]
STATS_ENV = {"V4_SERVE_STATS_LOG": "1", "DSV4_DECODE_PROF": "1", "V4_DEC_TRACE": "2"}
ARMS = {
    # arm: (env beyond COMMON, env that must be unset, probe build?, prefill path wanted)
    "W": (dict(STATS_ENV), ["COLI_CUDA_MOE_BATCH_MIN"], True, "bank"),
    "GB": (dict(STATS_ENV), ["COLI_CUDA_MOE_BATCH_MIN"], True, "bank"),
    "U": (dict(STATS_ENV, COLI_CUDA_MOE_BATCH_MIN="100000"), [], True, "union"),
    "GBn": (dict(STATS_ENV), ["COLI_CUDA_MOE_BATCH_MIN"], False, "bank"),
}
UNSET = ["DSV4_CUDA_VRAM_RESERVE_MB", "COLI_CUDA_MOE_DOUBLE", "DSV4_CUDA_EXPERT_MIRRORS", "DSV4_CUDA_PIN_HOST",
         "V4_LOGIT_LOG", "V4_EXPERT_UNION"] + ft.NEVER
TRACE_KEYS = ("calls", "total_s", "fetch_wait_s", "attach_s", "uploads", "gpu_s", "store_fetches",
              "req", "hits", "misses", "bytes", "disk_s", "wait_s")
WINDOWS = ((1, 3), (4, 8), (9, 16), (17, 99))   # decode forwards (1 = the first decode forward)


def trace_rows(log):
    """{ordinal: fields} of the v4_dec_trace lines (first request only: ordinals restart at 1)"""
    out = {}
    for l in log:
        if l.startswith("v4_dec_trace "):
            f = ft.fields(l)
            o = int(f.get("ord", -1))
            if o == 1 and out:
                break
            out[o] = f
    return out


def per_forward(rows):
    """per decode forward j (1..N): the counters it added (cum[ord j+1] - cum[ord j]) and its time"""
    out = []
    for j in sorted(rows):
        if j + 1 in rows:
            a, b = rows[j], rows[j + 1]
            d = {k: round(b.get(k, 0) - a.get(k, 0), 6) for k in TRACE_KEYS}
            d["t_ms"] = round(1000 * (b.get("t", 0) - a.get("t", 0)), 2)
            d["fwd"] = j
            out.append(d)
    return out


def residency(log):
    """decode-start RAM tier: per layer resident count, pinned residents, pins and their usage"""
    layers = []
    for l in log:
        if not l.startswith("v4_dec_res ") or "no-hot-policy" in l:
            continue
        m = re.search(r" layer=(\d+) .* res=(\S*) n=(\d+) pinned_resident=(\d+) pins=(\S*)", l)
        if not m:
            continue
        res = {}
        for item in filter(None, m.group(2).split(",")):
            p = item.endswith("p")
            e, u, age = item.rstrip("p").split(":")
            res[int(e)] = (int(u), int(age), p)
        pins = [int(x) for x in m.group(5).split(",") if x not in ("", "-1")]
        layers.append({"layer": int(m.group(1)), "n": int(m.group(3)), "pinned_resident": int(m.group(4)),
                       "res": res, "pins": pins})
        if len(layers) >= 43 and layers[-1]["layer"] == 42:
            break
    if not layers:
        return None
    n = [x["n"] for x in layers]
    usage1 = [sum(1 for u, _, _ in x["res"].values() if u <= 1) for x in layers]
    pin_usage = [x["res"][e][0] for x in layers for e in x["pins"] if e in x["res"]]
    lowest = [x["pins"] == sorted(x["pins"]) == list(range(len(x["pins"]))) for x in layers if x["pins"]]
    return {"layers": len(layers), "resident_mean": round(statistics.mean(n), 2),
            "pinned_resident_mean": round(statistics.mean(x["pinned_resident"] for x in layers), 2),
            "pins_mean": round(statistics.mean(len(x["pins"]) for x in layers), 2),
            "resident_usage<=1_mean": round(statistics.mean(usage1), 2),
            "resident_usage_median": ft.med([u for x in layers for u, _, _ in x["res"].values()]),
            "pin_usage_median": ft.med(pin_usage), "pin_usage_max": max(pin_usage) if pin_usage else None,
            "layers_pins_are_lowest_ids": sum(lowest),
            "_sets": {x["layer"]: sorted(x["res"]) for x in layers}}


def layer_rows(log):
    """v4_dec_layer lines of the first request: {(ord, layer): fields + routed ids}"""
    out = {}
    for l in log:
        if l.startswith("v4_dec_layer "):
            f = ft.fields(l)
            m = re.search(r"routed=([\d,]*)", l)
            f["routed"] = [int(x) for x in m.group(1).split(",") if x] if m else []
            key = (int(f.get("ord", -1)), int(f.get("layer", -1)))
            if key in out:
                break        # a second request
            out[key] = f
    return out


def sample(s, arm):
    extra, unset, probe, path = ARMS[arm]
    probs = ft.env_problems(s, dict(ft.COMMON, **extra), unset + UNSET)
    log = s["log"]
    if s["meta"].get("client_rc") != "0":
        probs.append("client_rc=%s" % s["meta"].get("client_rc"))
    if ft.grep(log, r"out of memory|FAILED|Traceback"):
        probs.append("%d OOM/FAILED/Traceback lines" % len(ft.grep(log, r"out of memory|FAILED|Traceback")))
    reserve = [m for l in log for m in re.findall(r"mirror-reserve=(\d+)MiB", l)]
    bank_on = len(ft.grep(log, r"moe-batch=on bank="))
    refills = len(ft.grep(log, r"moe-batch refill "))
    if reserve != ["3100"]:
        probs.append("mirror-reserve lines %s (want exactly one, 3100)" % reserve)
    if ft.grep(log, r"moe-batch=off"):
        probs.append("moe-batch=off line: %s" % ft.grep(log, r"moe-batch=off")[0][:120])
    start = next((ft.fields(l) for l in log if l.startswith("v4_dec_trace_start ")), None)
    if path == "bank" and (not bank_on or not refills):
        probs.append("GPU bank not used (moe-batch=on lines %d, refill lines %d)" % (bank_on, refills))
    if path == "union" and (bank_on or refills):
        probs.append("GPU bank used in the CPU-union arm (moe-batch=on lines %d, refill lines %d)" % (bank_on, refills))
    if probe:
        if not start:
            probs.append("no v4_dec_trace_start line")
        elif path == "bank" and not (start.get("bank", 0) > 0 and start.get("union", 0) == 0):
            probs.append("prefill chunk-layers bank=%s union=%s (want bank>0, union=0)" % (start.get("bank"), start.get("union")))
        elif path == "union" and not (start.get("bank", 0) == 0 and start.get("union", 0) > 0):
            probs.append("prefill chunk-layers bank=%s union=%s (want bank=0, union>0)" % (start.get("bank"), start.get("union")))
    elif ft.grep(log, r"^v4_dec_(trace|trace_start|layer|res) "):
        probs.append("probe lines in a non-probe sample")
    r = s["rows"][0] if s["rows"] else {}
    if r.get("text_sha256") != REF_TEXT:
        probs.append("text %s is not the reference %s" % (str(r.get("text_sha256"))[:12], REF_TEXT[:12]))
    cm = ft.chunk_metrics(r) if r else {"n": 0, "interval_ms": []}
    turns = ft.f42_turns(log)
    t = turns[0] if turns else {}
    rows = trace_rows(log)
    fw = per_forward(rows)
    lay = layer_rows(log)
    first = sorted([v for (o, _), v in lay.items() if o == 1], key=lambda v: v.get("layer", 0))
    prof = ft.decprof(log, [int(t.get("prompt", 0))]) if t else [[]]
    win = {}
    for a, b in WINDOWS:
        sel = [x for x in fw if a <= x["fwd"] <= b]
        win["%d-%d" % (a, b)] = {k: round(sum(x[k] for x in sel), 4) for k in
                                 ("t_ms", "fetch_wait_s", "attach_s", "uploads", "misses", "hits", "bytes")} if sel else None
    res = residency(log)
    if probe and not res:
        probs.append("no v4_dec_res lines")
    cum = {k: round(rows[max(rows)].get(k, 0), 4) for k in TRACE_KEYS} if rows else {}
    return {
        "k": s["k"], "seq": s["meta"].get("seq"), "binary_sha256": s["meta"].get("binary_sha256"),
        "wall_s": s["meta"].get("wall_s"), "ttft_s": r.get("ttft_s"), "chunks": cm.get("n"),
        "finish": r.get("finish_reason"), "text_sha256": r.get("text_sha256"),
        "client_tok_s": cm.get("rate_all"), "client_decode_s": round(sum(cm["interval_ms"]) / 1000, 3),
        "interval_ms": cm["interval_ms"], "reserve": reserve, "bank_on_lines": bank_on, "refill_lines": refills,
        "prefill_paths": {k: start.get(k) for k in ("bank", "union", "rows")} if start else None,
        "prefill_store": {k: start.get(k) for k in ("req", "hits", "misses", "bytes")} if start else None,
        "turn": {k: t.get(k) for k in ("prompt", "completion", "decode_s", "tok_s", "hit", "expert_wait_s")},
        "dec_moe": t.get("dec"), "trace_total": cum, "forwards": fw, "windows": win,
        "server_decode_s": round(rows[max(rows)].get("t", 0), 4) if rows else None,
        "first_forward": {"hits": sum(v.get("hits", 0) for v in first), "misses": sum(v.get("misses", 0) for v in first),
                          "uploads": sum(v.get("uploads", 0) for v in first),
                          "fetch_ms": round(sum(v.get("fetch_ms", 0) for v in first), 2),
                          "layers": len(first)} if first else None,
        "first_routed": {int(v["layer"]): v["routed"] for v in first},
        "decprof_moe_ms": [round(x.get("moe", 0)) for x in prof[0]] if prof else [],
        "residency": res, "gpu0_max_mib": ft.gpu_max(s["dir"]), "problems": probs}


def summarize(base):
    out = {"kind": "f42v2", "arms": {}}
    for arm in ARMS:
        ss = ft.samples(base, arm)
        if ss:
            out["arms"][arm] = [sample(s, arm) for s in ss]
    real = {a: v for a, v in out["arms"].items() if a != "W"}
    out["text_identity"] = sorted({x["text_sha256"] for v in real.values() for x in v if x["text_sha256"]})
    metric = {
        "client tok/s": lambda x: x["client_tok_s"],
        "client decode s": lambda x: x["client_decode_s"],
        "ttft s": lambda x: x["ttft_s"],
        "server decode s (trace)": lambda x: x["server_decode_s"],
        "fetch_wait s": lambda x: x["trace_total"].get("fetch_wait_s") if x["trace_total"] else (x["dec_moe"] or {}).get("fetch_wait_s"),
        "attach s": lambda x: x["trace_total"].get("attach_s") if x["trace_total"] else (x["dec_moe"] or {}).get("attach_s"),
        "uploads": lambda x: x["trace_total"].get("uploads") if x["trace_total"] else (x["dec_moe"] or {}).get("uploads"),
        "dec_moe total s": lambda x: x["trace_total"].get("total_s") if x["trace_total"] else (x["dec_moe"] or {}).get("total_s"),
        "store misses (SSD reads)": lambda x: x["trace_total"].get("misses"),
        "store hits": lambda x: x["trace_total"].get("hits"),
        "store GiB read": lambda x: round(x["trace_total"]["bytes"] / 2 ** 30, 3) if x["trace_total"] else None,
        "first fwd RAM hits (of 258)": lambda x: (x["first_forward"] or {}).get("hits"),
        "first fwd misses": lambda x: (x["first_forward"] or {}).get("misses"),
        "decode-start resident/layer": lambda x: (x["residency"] or {}).get("resident_mean"),
        "decode-start pins/layer": lambda x: (x["residency"] or {}).get("pins_mean"),
        "decode-start pin usage median": lambda x: (x["residency"] or {}).get("pin_usage_median"),
        "decode-start layers pins=lowest ids": lambda x: (x["residency"] or {}).get("layers_pins_are_lowest_ids"),
        "decode-start residents usage<=1/layer": lambda x: (x["residency"] or {}).get("resident_usage<=1_mean"),
        "gpu0 max MiB": lambda x: x["gpu0_max_mib"],
    }
    for a, b in WINDOWS:
        w = "%d-%d" % (a, b)
        for k in ("t_ms", "fetch_wait_s", "misses", "uploads", "attach_s"):
            metric["fwd %s %s" % (w, k)] = (lambda x, w=w, k=k: (x["windows"].get(w) or {}).get(k))
    table = {}
    for label, f in metric.items():
        row = {arm: {"median": ft.med([f(x) for x in v]), "samples": [f(x) for x in v]} for arm, v in real.items()}
        m = {arm: row[arm]["median"] for arm in row}
        row["GB-U"] = ft.diff(m.get("GB"), m.get("U"))
        row["GB/U"] = ft.ratio(m.get("GB"), m.get("U"))
        row["GBn/GB"] = ft.ratio(m.get("GBn"), m.get("GB"))
        table[label] = row
    out["table"] = table
    # per decode forward, mean over samples: GB-U of time / fetch wait / misses / uploads
    curve = []
    for j in range(1, 40):
        row = {"fwd": j}
        for arm in ("GB", "U"):
            xs = [f for x in real.get(arm, []) for f in x["forwards"] if f["fwd"] == j]
            if xs:
                row[arm] = {k: round(statistics.mean(f[k] for f in xs), 4)
                            for k in ("t_ms", "fetch_wait_s", "attach_s", "uploads", "misses", "hits")}
        if "GB" in row and "U" in row:
            row["GB-U"] = {k: round(row["GB"][k] - row["U"][k], 4) for k in row["GB"]}
            curve.append(row)
    out["per_forward"] = curve
    # same-routing check: the first decode forward routes the same experts in every probe sample
    routes = {json.dumps(x["first_routed"], sort_keys=True) for arm in ("GB", "U") for x in real.get(arm, []) if x["first_routed"]}
    out["first_forward_routing_distinct"] = len(routes)
    # overlap of the decode-start RAM sets with the first forward's routed experts, per arm
    ov = {}
    for arm in ("GB", "U"):
        vals = []
        for x in real.get(arm, []):
            sets = (x["residency"] or {}).get("_sets") or {}
            if sets and x["first_routed"]:
                vals.append(sum(len(set(sets.get(l, [])) & set(r)) for l, r in x["first_routed"].items()))
        ov[arm] = vals
    out["first_forward_routed_in_ram_at_start"] = ov
    L = ["F42 v2: decode after GPU-bank (GB) vs CPU-union (U) prefill, identical text, equal reserve: %s" % base,
         "texts (all arms but W): %s  reference %s" % ([t[:12] for t in out["text_identity"]], REF_TEXT[:12]),
         "first-forward routing distinct across GB/U probe samples: %s" % out["first_forward_routing_distinct"],
         "first-forward routed experts resident in RAM at decode start (sum over layers) GB %s U %s" % (ov.get("GB"), ov.get("U")),
         "%-40s %10s %10s %10s %9s %8s %8s" % ("metric (median of samples)", "GB", "U", "GBn", "GB-U", "GB/U", "GBn/GB")]
    for label, r in table.items():
        L.append("%-40s %10s %10s %10s %9s %8s %8s" % (label, r.get("GB", {}).get("median"), r.get("U", {}).get("median"),
                                                     r.get("GBn", {}).get("median"), r["GB-U"], r["GB/U"], r["GBn/GB"]))
    L.append("per decode forward, mean over samples, GB-U: t_ms / fetch_wait_ms / misses / uploads / attach_ms")
    for row in curve[:30]:
        d = row["GB-U"]
        L.append("  fwd %2d  %+8.1f  %+8.1f  %+6.1f  %+6.1f  %+7.1f" % (row["fwd"], d["t_ms"], 1000 * d["fetch_wait_s"],
                                                                    d["misses"], d["uploads"], 1000 * d["attach_s"]))
    for arm, v in out["arms"].items():
        for x in v:
            L.append("  %-3s s%d seq=%s ttft=%s chunks=%s tok/s=%s reserve=%s paths=%s first_fwd=%s %s" % (
                arm, x["k"], x["seq"], x["ttft_s"], x["chunks"], x["client_tok_s"], x["reserve"], x["prefill_paths"],
                x["first_forward"], ("PROBLEMS: " + "; ".join(x["problems"])[:400]) if x["problems"] else "ok"))
    return out, L


def strip(o):
    if isinstance(o, dict):
        return {k: strip(v) for k, v in o.items() if k not in ("_sets",)}
    if isinstance(o, list):
        return [strip(v) for v in o]
    return o


# ---------------------------------------------------------------- self test (synthetic samples)
def _fake_log(arm, extra_miss):
    """serve.log lines in the probe's exact formats (f42v2_probe_patch.py)"""
    probe = ARMS[arm][2]
    bank = ARMS[arm][3] == "bank"
    log = ["v4_hot_policy pin_slots_per_layer=16 repin_interval=6 mode=resident-ram rows16=hot-pins",
           "v4_gpu mirror-reserve=3100MiB (132-slot bank 1683MiB x1 + 600MiB headroom + 64 mirrors; DSV4_CUDA_VRAM_RESERVE_MB overrides)"]
    if bank:
        log += ["v4_gpu moe-batch=on bank=132-experts", "v4_gpu moe-batch refill layer=0 missing=85 lookup=0.02s upload=0.16s"]
    log += ["decprof position=%d layers=43 hc=5 attn=122 moe=%d ms" % (2005 + i, 250 + (i < 5) * 80) for i in range(24)]
    if probe:
        log.append("v4_dec_trace_start ord=1 pos=2005 wall=1792140000.0000 prefill_moe_chunk_layers bank=%d union=%d rows=0 "
                   "store_total req=9000 hits=5000 misses=4000 bytes=40000000000 prefetched=0 prefetch_hits=0 "
                   "resident_bytes=1 capacity_bytes=2 disk_s=10.000 wait_s=5.000 dec_moe_total calls=0 uploads=0 (process totals)"
                   % ((688, 0) if bank else (0, 688)))
        for layer in range(43):
            if bank:
                res = ",".join("%d:1:%d%s" % (e, 900 - e, "p" if e < 16 else "") for e in range(59))
                pins = ",".join(str(e) for e in range(16))
            else:
                res = ",".join("%d:%d:%d%s" % (e, 9 - e % 9, 900 - e, "p" if e % 4 == 0 and e < 64 else "") for e in range(30, 89))
                pins = ",".join(str(e) for e in range(32, 96, 4))
            log.append("v4_dec_res tag=decode-start layer=%d lreq=1000 clock=99999 res=%s n=59 pinned_resident=16 pins=%s"
                       % (layer, res, pins))
        cum = dict.fromkeys(TRACE_KEYS, 0.0)
        for o in range(1, 26):
            if o > 1:
                f = o - 1
                miss = 60 + (extra_miss if f <= 3 else 0)
                cum["calls"] += 43; cum["total_s"] += 0.25 + miss * 0.001; cum["fetch_wait_s"] += miss * 0.001
                cum["attach_s"] += 0.08; cum["uploads"] += 70; cum["gpu_s"] += 0.03; cum["store_fetches"] += 258
                cum["req"] += 258; cum["hits"] += 258 - miss; cum["misses"] += miss; cum["bytes"] += miss * 13369344
                cum["disk_s"] += miss * 0.002; cum["wait_s"] += miss * 0.001
                for layer in range(43):
                    lm = miss // 43 + (1 if layer < miss % 43 else 0)
                    log.append("v4_dec_layer ord=%d layer=%d routed=%s req=6 hits=%d misses=%d bytes=%d uploads=2 "
                               "fetch_ms=%.3f attach_ms=1.000 total_ms=6.000"
                               % (f, layer, ",".join(str(e) for e in (1, 5, 20, 40, 70, 100)), 6 - lm, lm, lm * 13369344, lm * 1.0))
            log.append("v4_dec_trace ord=%d pos=%d tok=%d t=%.4f wall=%.4f calls=%d total_s=%.4f fetch_wait_s=%.4f "
                       "attach_s=%.4f uploads=%d gpu_s=%.4f store_fetches=%d req=%d hits=%d misses=%d bytes=%d "
                       "prefetched=0 disk_s=%.4f wait_s=%.4f"
                       % (o, 2004 + o, 100 + o, cum["total_s"] + 0.12 * (o - 1), 1792140000.0 + o, cum["calls"], cum["total_s"],
                          cum["fetch_wait_s"], cum["attach_s"], cum["uploads"], cum["gpu_s"], cum["store_fetches"], cum["req"],
                          cum["hits"], cum["misses"], cum["bytes"], cum["disk_s"], cum["wait_s"]))
    log += ["v4_dec_moe calls=1032 total_s=8.00 fetch_wait_s=2.00 attach_s=2.00 uploads=1680 gpu_s=0.80 (cumulative)",
            "v4_serve_turn prompt=2006 completion=24 decode_s=11.00 tok_s=2.180 hit=60.0% expert_disk_s=1 expert_wait_s=1 "
            "expert_matmul_s=1 attention_s=1 rss_gb=40.0 vram_first_hits_total=0 store_fetches_total=6192"]
    return log


def selftest():
    tmp = tempfile.mkdtemp(prefix="f42v2-selftest-")
    t0 = time.time() - 3600
    seq = 0
    text = "REF"
    for arm in ("W", "GB", "U", "GBn"):
        for k in (1, 2):
            seq += 1
            r = ft._fake_req("long_prefill", t0, 82.0 if arm != "U" else 219.0, 25,
                             {"GB": 0.47, "W": 0.47, "GBn": 0.47, "U": 0.44}[arm], text)
            r["finish_reason"] = "stop"
            r["text_sha256"] = REF_TEXT
            nv = [(t0 + i, 9000) for i in range(1, 80)] + [(t0 + 81 + i, 7400 + min(i * 100, 13900)) for i in range(30)]
            ft._fake_sample(tmp, arm, k, seq, dict(ARMS[arm][0]), [r], _fake_log(arm, 40 if arm in ("GB", "W", "GBn") else 0), nv)
    out, L = summarize(tmp)
    probs = [(a, x["k"], x["problems"]) for a, v in out["arms"].items() for x in v if x["problems"]]
    assert not probs, probs
    t = out["table"]
    assert t["fwd 1-3 misses"]["GB-U"] == 120.0, t["fwd 1-3 misses"]
    assert t["fwd 4-8 misses"]["GB-U"] == 0.0, t["fwd 4-8 misses"]
    assert t["uploads"]["GB-U"] == 0.0 and t["attach s"]["GB-U"] == 0.0, (t["uploads"], t["attach s"])
    assert t["decode-start layers pins=lowest ids"]["GB"]["median"] == 43, t["decode-start layers pins=lowest ids"]
    assert t["decode-start layers pins=lowest ids"]["U"]["median"] == 0
    assert t["first fwd misses"]["GB-U"] == 40.0, t["first fwd misses"]
    assert out["per_forward"][0]["GB-U"]["misses"] == 40.0
    assert out["first_forward_routing_distinct"] == 1
    assert out["text_identity"] == [REF_TEXT]
    assert out["first_forward_routed_in_ram_at_start"]["GB"] and out["first_forward_routed_in_ram_at_start"]["U"]
    # a U sample that used the bank, and a GB sample with a different reserve, must be flagged
    bad = os.path.join(tmp, "bad")
    ft._fake_sample(bad, "U", 1, 1, dict(ARMS["U"][0]), [ft._fake_req("long_prefill", t0, 82.0, 25, 0.47, text)],
                    _fake_log("GB", 0), [(t0 + 1, 9000)])
    lg = [l.replace("mirror-reserve=3100MiB", "mirror-reserve=2800MiB") for l in _fake_log("GB", 0)]
    ft._fake_sample(bad, "GB", 1, 2, dict(ARMS["GB"][0]), [ft._fake_req("long_prefill", t0, 82.0, 25, 0.47, text)], lg,
                    [(t0 + 1, 9000)])
    o2, _ = summarize(bad)
    pu = " ".join(o2["arms"]["U"][0]["problems"])
    pg = " ".join(o2["arms"]["GB"][0]["problems"])
    assert "GPU bank used in the CPU-union arm" in pu and "want bank=0" in pu and "not the reference" in pu, pu
    assert "mirror-reserve lines ['2800']" in pg, pg
    json.dumps(strip(out))
    print("selftest ok (%s)" % tmp)
    return 0


def main(argv):
    if argv[:1] == ["selftest"]:
        return selftest()
    if len(argv) == 2 and argv[0] == "summarize":
        out, L = summarize(argv[1])
        json.dump(strip(out), open(os.path.join(argv[1], "summary.json"), "w"), indent=1)
        print("\n".join(L))
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
