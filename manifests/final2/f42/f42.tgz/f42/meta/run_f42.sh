#!/bin/bash
# F42 diagnosis: why does the answer right after a long GPU-batch prefill decode slower than after
# a CPU-union prefill (final PR #1 benchmark: 24-token answer to the 1,992-token prompt 2.054 vs
# 2.247 chunks/s, -8.6 %; the 3,005-token answer -2.4 %; short-prompt 6x300 decode only -0.6 %)?
# shadowfax only. Stops llama.cpp ONCE; the EXIT trap ALWAYS restarts it and waits for /health ok.
# Launch (own transient unit, survives an ssh drop):
#   systemd-run --user --unit=colibri-final2-f42 --collect -p TimeoutStopSec=900 \
#     -p WorkingDirectory=/home/maplemercury/colibri-bench/final2 /bin/bash /home/maplemercury/colibri-bench/final2/run_f42.sh
#   progress: tail /home/maplemercury/colibri-bench/final2/f42/run.log
#
# Build: the pr2 tip d0e19de2 (/tmp/cw/r6-pr2); with no PR #2 switch it runs the PR #1 code paths
# (P1 == G1 in the final PR #2 run). Every arm: --ram 40 --ctx 8192, COMMON_ENV of final_common.sh,
# a cold server per sample (env -i), plus V4_SERVE_STATS_LOG=1 (per-turn v4_serve_turn + cumulative
# v4_dec_moe lines: decode MoE wall, store fetch wait, VRAM attach time and mirror uploads, GPU time)
# and DSV4_DECODE_PROF=1 (one decprof line per decode token: hc / attention / MoE ms). Both are
# stderr diagnostics; neither changes a computed value.
# Client bench_f42.py (one cold server, two requests, per-chunk timestamps, full text):
#   long_200   the 1,992-token filler of bench_pr1.py byte for byte + a question asking for a long
#              answer, max_tokens 200 (the original closing question ends the answer with EOS after
#              24 tokens whatever max_tokens says; the first 24 chunks are the comparable span)
#   short_200  bench_decode.py prompt 0, max_tokens 200, same server: decode after a short prompt (control)
# Arms (switches checked against docs/deepseek-v4.md at d0e19de2 and the tree's getenv calls):
#   GB  COLI_CUDA_MOE_BATCH=1 (COMMON_ENV): GPU-batch prefill on the 132-slot bank; decode-mirror
#       reserve = the bank-sized default, 3100 MiB (600 + 1683 bank + 64 mirrors, logged)
#   CU  COLI_CUDA_MOE_BATCH=0: CPU-union prefill (what dev ran for REAP); reserve default 600 MiB
#   GR  GB + DSV4_CUDA_VRAM_RESERVE_MB=600: GPU-batch prefill with CU's 600 MiB reserve
#   GB-GR changes only the reserve; GR-CU changes only the prefill path (same 600 MiB reserve).
#   (dev itself, in the PR #1 benchmark, kept 2800 MiB: its fixed default whenever COLI_CUDA_MOE_BATCH=1
#   is set, even though it refuses the bank for REAP; it can overshoot that by up to 64 mirrors.)
#   3 cold samples per arm, interleaved: round k runs the arms rotated by k-1 (GB CU GR / CU GR GB / GR GB CU).
# Captured per sample (final2/f42/<arm>/s<k>/): serve.log (v4_serve_turn, v4_dec_moe, decprof,
# mode lines), bench.jsonl (per-chunk times, texts), nvsmi.csv every 1 s (VRAM over time: bank
# release, mirror-cache growth and plateau; mirror count = (decode VRAM - prefill VRAM without the
# bank) / 12.75 MiB, final_tools.py), sample.txt, engine_environ.txt, procs.txt, gpu_*.csv, mode.txt.
# Summary (final_tools.py summarize f42): per-arm medians of tok/s over the first 24 chunks, after
# them and overall, per-token decode MoE / fetch-wait / attach / upload / GPU and decprof attention /
# MoE, hit rate, mirror count, text identity; the long answer's per-token gap split into
# GB-GR (reserve) + GR-CU (prefill path).
# Expected GPU window ~50 min (GB/GR ~4.5 min, CU ~7 min per sample, + llama stop/restore).

EXP=f42
# PREFLIGHT_ONLY=1: run every preflight check (CPU only, nothing stopped or started), log to
# final2/f42-preflight/run.log and exit before the EXIT trap exists and before llama is touched
[ "${PREFLIGHT_ONLY:-0}" = 1 ] && EXP=f42-preflight
MAX_GPU_S=$((75 * 60))      # hard cap: no new sample once the llama-down window would pass 75 min
NVSMI_MS=1000
source /home/maplemercury/colibri-bench/final2/final_common.sh

PR2_SHA=d0e19de23c3baf314ee932347c42d5f6d49ef4fb
PR2=/tmp/cw/r6-pr2
MODE_RE='moe-batch=|moe-double|mirror-reserve|mirror-cache:|DSV4 CUDA\] device|^v4_serve_turn|^v4_dec_moe|out of memory'
STATS="V4_SERVE_STATS_LOG=1 DSV4_DECODE_PROF=1"

declare -A XENV EST
XENV[GB]="$STATS";                                EST[GB]=300
XENV[CU]="$STATS COLI_CUDA_MOE_BATCH=0";          EST[CU]=450
XENV[GR]="$STATS DSV4_CUDA_VRAM_RESERVE_MB=600";  EST[GR]=300
TMO=1500

lock_or_exit
log "run_f42.sh start (pid $$)"
preflight_common bench_f42.py bench_common.py bench_pr1.py bench_decode.py
preflight_tree $PR2 $PR2_SHA
preflight_switch $PR2 COLI_CUDA_MOE_BATCH DSV4_CUDA_VRAM_RESERVE_MB V4_SERVE_STATS_LOG DSV4_DECODE_PROF COLI_CUDA_MOE_BATCH_MIN
preflight_doc $PR2 COLI_CUDA_MOE_BATCH DSV4_CUDA_VRAM_RESERVE_MB V4_SERVE_STATS_LOG DSV4_DECODE_PROF
grep -q 'mirror-reserve=' $PR2/c/deepseek_v4.c || die_pre "no mirror-reserve log line in $PR2"
grep -q 'fprintf(stderr, "decprof position=' $PR2/c/deepseek_v4.c || die_pre "no decprof line in $PR2"
python3 -c "import sys; sys.path.insert(0, '$CLIENTS'); import bench_common as b; b.long_prompt(); b.load_short_prompt()" \
    || die_pre "client prompts do not load / changed"

if [ "${PREFLIGHT_ONLY:-0}" = 1 ]; then log "PREFLIGHT_ONLY: all checks passed; exiting before llama is touched"; exit 0; fi
arm_trap
capture_meta $PR2
stop_llama

ORDER="GB CU GR"
for k in 1 2 3; do
    for arm in $(rotate $((k - 1)) $ORDER); do
        if over_budget $(est_for $arm ${EST[$arm]}); then log "budget: skipping $arm s$k (GPU window $(gpu_elapsed) s)"; continue; fi
        # shellcheck disable=SC2086
        sample $arm $k $PR2 f42 $TMO ${XENV[$arm]}
        log "stats $arm s$k: $(grep -h '^v4_serve_turn' "$OUT/$arm/s$k/serve.log" | grep -oE 'prompt=[0-9]+ completion=[0-9]+ decode_s=[0-9.]+ tok_s=[0-9.]+ hit=[0-9.]+%' | tr '\n' '|') mirror-reserve: $(grep -ohE 'mirror-reserve=[0-9]+MiB' "$OUT/$arm/s$k/serve.log" | head -1)"
    done
done
finish f42
