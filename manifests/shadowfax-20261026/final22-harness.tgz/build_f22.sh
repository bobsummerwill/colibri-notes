#!/bin/bash
# final22 (2026-10-25 night): base = fix A dd03a9de (#2401, PR #2s base), PR #2 5b3f4601 (rebased onto #2401): CUDA builds
# (final6 make line); dev 77530b49 and fix B 78dda872: CUDA=1 VK=1 builds (build_f15.sh make line) for the pure-Vulkan arms
W=~/colibri-bench/cw22
B=~/colibri-bench/final22/builds; mkdir -p $B
G=$HOME/colibri-bench/vulkansdk/1.4.363.0/x86_64/bin/glslc
MAKE_CUDA="make -f Makefile.deepseek-v4 deepseek-v4 CUDA=1 CUDA_HOME=/usr NVCC=/usr/bin/nvcc CUDA_ARCH=sm_86 NO_TC=1 -j14"
MAKE_VK="make -f Makefile.deepseek-v4 deepseek-v4 CUDA=1 VK=1 GLSLC=$G CUDA_HOME=/usr NVCC=/usr/bin/nvcc CUDA_ARCH=sm_86 NO_TC=1 -j14"
cd $W/repo
for spec in base:f22/fixa:cuda pr2:f22/pr2:cuda devvk:77530b49:vk fixbvk:f22/fixb:vk; do
  IFS=: read n ref kind <<< "$spec"; t=$W/f22-$n
  [ -d $t ] || git worktree add -q --detach $t $ref || { echo "f22-$n worktree failed" >> $B/status; continue; }
  if [ $kind = vk ]; then ML="$MAKE_VK"; X="CPATH=$HOME/colibri-bench/vulkansdk/1.4.363.0/x86_64/include"; else ML="$MAKE_CUDA"; X=; fi
  ( cd $t/c && echo "tree=$t sha=$(git rev-parse HEAD) tree_sha=$(git rev-parse "HEAD^{tree}") start=$(date -Is)" &&
    env -i PATH=/usr/local/bin:/usr/bin:/bin HOME=$HOME $X nice -n 15 $ML; echo "EXIT=$? end=$(date -Is)" ) > $B/f22-$n.build.log 2>&1
  echo "f22-$n $(tail -1 $B/f22-$n.build.log) warnings=$(grep -iE "warning|error" $B/f22-$n.build.log | grep -vc lto-wrapper) bin=$(sha256sum $t/c/deepseek_v4 | cut -c1-16)" >> $B/status
done
echo done >> $B/status
